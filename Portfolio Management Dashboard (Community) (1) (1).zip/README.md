
  # Portfolio Management Dashboard (Community)

  This is a code bundle for Portfolio Management Dashboard (Community). The original project is available at https://www.figma.com/design/o0HeYfGDvsZ515KdZ4zx5N/Portfolio-Management-Dashboard--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  