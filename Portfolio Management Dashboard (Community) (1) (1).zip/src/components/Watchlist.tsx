import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, TrendingDown, Plus } from "lucide-react";
import { Button } from "./ui/button";

const watchlistStocks = [
  {
    symbol: "MSFT",
    company: "Microsoft Corporation",
    price: 415.75,
    change: 8.25,
    changePercent: 2.02,
    volume: "28.5M",
  },
  {
    symbol: "META",
    company: "Meta Platforms Inc.",
    price: 485.20,
    change: -12.30,
    changePercent: -2.47,
    volume: "15.2M",
  },
  {
    symbol: "NFLX",
    company: "Netflix Inc.",
    price: 625.90,
    change: 15.60,
    changePercent: 2.56,
    volume: "8.7M",
  },
  {
    symbol: "SHOP",
    company: "Shopify Inc.",
    price: 89.45,
    change: -1.85,
    changePercent: -2.03,
    volume: "12.4M",
  },
  {
    symbol: "SQ",
    company: "Block Inc.",
    price: 67.30,
    change: 3.45,
    changePercent: 5.40,
    volume: "18.9M",
  },
];

export function Watchlist() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Market Watchlist</CardTitle>
        <Button size="sm" variant="outline">
          <Plus className="h-4 w-4 mr-2" />
          Add Stock
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {watchlistStocks.map((stock) => (
            <div key={stock.symbol} className="flex items-center justify-between rounded-lg border p-4">
              <div className="flex items-center space-x-4">
                <div>
                  <p className="font-medium">{stock.symbol}</p>
                  <p className="text-sm text-muted-foreground">{stock.company}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium">${stock.price.toFixed(2)}</p>
                <div className="flex items-center space-x-1 text-sm">
                  {stock.change >= 0 ? (
                    <TrendingUp className="h-3 w-3 text-green-600" />
                  ) : (
                    <TrendingDown className="h-3 w-3 text-red-600" />
                  )}
                  <span
                    className={stock.change >= 0 ? "text-green-600" : "text-red-600"}
                  >
                    {stock.change >= 0 ? "+" : ""}${stock.change.toFixed(2)} ({stock.changePercent >= 0 ? "+" : ""}{stock.changePercent.toFixed(2)}%)
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">Vol: {stock.volume}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}