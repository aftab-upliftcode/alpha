import {
  PieChart,
  TrendingUp,
  Wallet,
  History,
  Eye,
  Settings,
  BarChart3,
  Home,
  Target,
  FileText,
  Brain,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "./ui/sidebar";
import { Badge } from "./ui/badge";

const getMainNavItems = (currentPage: string) => [
  {
    title: "Dashboard",
    icon: Home,
    isActive: currentPage === "Dashboard",
    badge: null,
  },
  {
    title: "AI insight",
    icon: Brain,
    isActive: currentPage === "AI insight",
    badge: null,
  },
  {
    title: "Portfolio",
    icon: BarChart3,
    isActive: currentPage === "Portfolio",
    badge: null,
  },
  {
    title: "Holdings",
    icon: Wallet,
    isActive: currentPage === "Holdings",
    badge: "12",
  },
  {
    title: "Performance",
    icon: TrendingUp,
    isActive: currentPage === "Performance",
    badge: null,
  },
];

const getAnalyticsItems = (currentPage: string) => [
  {
    title: "Asset Allocation",
    icon: PieChart,
    isActive: currentPage === "Asset Allocation",
    badge: null,
  },
  {
    title: "Risk Analysis",
    icon: Target,
    isActive: currentPage === "Risk Analysis",
    badge: "New",
  },
  {
    title: "Reports",
    icon: FileText,
    isActive: currentPage === "Reports",
    badge: null,
  },
];

const analyticsItems1 = [
  {
    title: "AI co-pilot",
    icon: PieChart,
    isActive: false,
    badge: null,
  },
  {
    title: "AI Summaries",
    icon: Target,
    isActive: false,
    badge: "New",
  },
  {
    title: "AI-Reports",
    icon: FileText,
    isActive: false,
    badge: null,
  },
];

const activityItems = [
  {
    title: "Transactions",
    icon: History,
    isActive: false,
    badge: "5",
  },
  {
    title: "Watchlist",
    icon: Eye,
    isActive: false,
    badge: "24",
  },
];

interface PortfolioSidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export function PortfolioSidebar({ currentPage, onPageChange }: PortfolioSidebarProps) {
  return (
    <Sidebar className="border-r-2">
      <SidebarHeader className="border-b border-sidebar-border p-6">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center shadow-lg">
            <BarChart3 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="font-semibold text-lg text-sidebar-foreground">
              Alpha.ai
            </h2>
            <p className="text-xs text-sidebar-foreground/70">
              AI Investment Platform
            </p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="px-3">
        {/* Main Navigation */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold text-sidebar-foreground/60 uppercase tracking-wider mb-2">
            Main
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {getMainNavItems(currentPage).map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    isActive={item.isActive}
                    onClick={() => onPageChange(item.title)}
                    className="group relative h-11 px-3 rounded-lg transition-all duration-200 hover:shadow-sm data-[active=true]:bg-gradient-to-r data-[active=true]:from-blue-500 data-[active=true]:to-purple-500 data-[active=true]:text-white data-[active=true]:shadow-lg cursor-pointer"
                  >
                    <item.icon className="h-5 w-5 transition-colors" />
                    <span className="font-medium">
                      {item.title}
                    </span>
                    {item.badge && (
                      <Badge
                        variant="secondary"
                        className="ml-auto h-5 px-1.5 text-xs bg-sidebar-accent text-sidebar-accent-foreground group-data-[active=true]:bg-white/20 group-data-[active=true]:text-white"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Analytics */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold text-sidebar-foreground/60 uppercase tracking-wider mb-2">
            Analytics
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {getAnalyticsItems(currentPage).map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    isActive={item.isActive}
                    onClick={() => onPageChange(item.title)}
                    className="group relative h-11 px-3 rounded-lg transition-all duration-200 hover:shadow-sm data-[active=true]:bg-gradient-to-r data-[active=true]:from-blue-500 data-[active=true]:to-purple-500 data-[active=true]:text-white data-[active=true]:shadow-lg cursor-pointer"
                  >
                    <item.icon className="h-5 w-5 transition-colors" />
                    <span className="font-medium">
                      {item.title}
                    </span>
                    {item.badge && (
                      <Badge
                        variant={
                          item.badge === "New"
                            ? "destructive"
                            : "secondary"
                        }
                        className="ml-auto h-5 px-1.5 text-xs group-data-[active=true]:bg-white/20 group-data-[active=true]:text-white"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Analytics */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold text-sidebar-foreground/60 uppercase tracking-wider mb-2">
            AI
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {analyticsItems1.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    isActive={item.isActive}
                    className="group relative h-11 px-3 rounded-lg transition-all duration-200 hover:shadow-sm data-[active=true]:bg-gradient-to-r data-[active=true]:from-blue-500 data-[active=true]:to-purple-500 data-[active=true]:text-white data-[active=true]:shadow-lg"
                  >
                    <item.icon className="h-5 w-5 transition-colors" />
                    <span className="font-medium">
                      {item.title}
                    </span>
                    {item.badge && (
                      <Badge
                        variant={
                          item.badge === "New"
                            ? "destructive"
                            : "secondary"
                        }
                        className="ml-auto h-5 px-1.5 text-xs group-data-[active=true]:bg-white/20 group-data-[active=true]:text-white"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Activity */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold text-sidebar-foreground/60 uppercase tracking-wider mb-2">
            Activity
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {activityItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    isActive={item.isActive}
                    className="group relative h-11 px-3 rounded-lg transition-all duration-200 hover:shadow-sm data-[active=true]:bg-gradient-to-r data-[active=true]:from-blue-500 data-[active=true]:to-purple-500 data-[active=true]:text-white data-[active=true]:shadow-lg"
                  >
                    <item.icon className="h-5 w-5 transition-colors" />
                    <span className="font-medium">
                      {item.title}
                    </span>
                    {item.badge && (
                      <Badge
                        variant="secondary"
                        className="ml-auto h-5 px-1.5 text-xs bg-sidebar-accent text-sidebar-accent-foreground group-data-[active=true]:bg-white/20 group-data-[active=true]:text-white"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-3">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton className="h-11 px-3 rounded-lg transition-all duration-200 hover:shadow-sm">
              <Settings className="h-5 w-5" />
              <span className="font-medium">Settings</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>

        {/* Portfolio Summary Card */}
        <div className="mt-4 p-4 rounded-lg bg-gradient-to-br from-green-50 to-blue-50 border border-green-200/50">
          <div className="text-center">
            <p className="text-xs text-green-700 font-medium mb-1">
              Total Portfolio Value
            </p>
            <p className="text-lg font-bold text-green-800">
              $124,568
            </p>
            <div className="flex items-center justify-center mt-1">
              <TrendingUp className="h-3 w-3 text-green-600 mr-1" />
              <span className="text-xs text-green-600 font-medium">
                +2.4% today
              </span>
            </div>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}