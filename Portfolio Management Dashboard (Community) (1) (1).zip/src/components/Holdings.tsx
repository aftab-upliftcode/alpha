import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  Brain,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Target,
  Lightbulb,
  Zap,
  Shield,
  DollarSign,
  Activity,
} from "lucide-react";

// Mock data for AI insights
const riskAnalysisData = [
  { name: "Tech Stocks", risk: 85, allocation: 45 },
  { name: "Bonds", risk: 25, allocation: 30 },
  { name: "Real Estate", risk: 55, allocation: 15 },
  { name: "Commodities", risk: 70, allocation: 10 },
];

const predictionData = [
  { month: "Jan", predicted: 120000, actual: 118500 },
  { month: "Feb", predicted: 125000, actual: 124200 },
  { month: "Mar", predicted: 128000, actual: 127800 },
  { month: "Apr", predicted: 132000, actual: null },
  { month: "May", predicted: 135000, actual: null },
  { month: "Jun", predicted: 138000, actual: null },
];

const optimizationData = [
  { name: "Current", value: 68, color: "#8884d8" },
  { name: "Optimized", value: 32, color: "#82ca9d" },
];

const marketSentimentData = [
  { category: "Technology", sentiment: 78, change: 5 },
  { category: "Healthcare", sentiment: 65, change: -2 },
  { category: "Finance", sentiment: 72, change: 8 },
  { category: "Energy", sentiment: 45, change: -12 },
  { category: "Consumer", sentiment: 58, change: 3 },
];

const aiRecommendations = [
  {
    type: "Holdings",
    title: "Portfolio Rebalancing Recommended",
    description:
      "Your tech allocation is 8% above optimal. Consider reducing by $12,000.",
    impact: "+2.3% expected annual return",
    confidence: 87,
    priority: "high",
  },
  {
    type: "opportunity",
    title: "Growth Opportunity Detected",
    description:
      "Healthcare sector showing strong momentum. Consider 5% allocation increase.",
    impact: "+1.8% portfolio growth potential",
    confidence: 73,
    priority: "medium",
  },
  {
    type: "risk",
    title: "Risk Alert: Concentration Risk",
    description:
      "Over-concentration in tech sector. Diversification recommended.",
    impact: "-15% risk reduction potential",
    confidence: 92,
    priority: "high",
  },
];

export function Holdings() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Brain className="h-8 w-8 text-blue-600" />
            AI Insights
          </h1>
          <p className="text-muted-foreground mt-1">
            Holdings Details
          </p>
        </div>
        <Badge
          variant="secondary"
          className="bg-blue-100 text-blue-700"
        >
          <Zap className="h-3 w-3 mr-1" />
          Live Analysis
        </Badge>
      </div>

      {/* Key AI Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              AI Confidence Score
            </CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              94%
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
              +2% from last week
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Risk Score
            </CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              6.8/10
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
              +0.2 this month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Optimization Score
            </CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              82%
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
              +5% potential improvement
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Predicted Return
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              +12.4%
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <Activity className="h-3 w-3 mr-1 text-blue-500" />
              Next 12 months
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs
        defaultValue="recommendations"
        className="space-y-4"
      >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="recommendations">
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="predictions">
            Predictions
          </TabsTrigger>
          <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
          <TabsTrigger value="sentiment">
            Market Sentiment
          </TabsTrigger>
        </TabsList>

        {/* AI Recommendations Tab */}
        <TabsContent
          value="recommendations"
          className="space-y-4"
        >
          <div className="grid gap-4">
            {aiRecommendations.map((rec, index) => (
              <Card
                key={index}
                className={`${rec.priority === "high" ? "border-l-4 border-l-red-500" : rec.priority === "medium" ? "border-l-4 border-l-orange-500" : "border-l-4 border-l-blue-500"}`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {rec.type === "rebalance" && (
                        <Target className="h-5 w-5 text-blue-600" />
                      )}
                      {rec.type === "opportunity" && (
                        <Lightbulb className="h-5 w-5 text-green-600" />
                      )}
                      {rec.type === "risk" && (
                        <AlertTriangle className="h-5 w-5 text-red-600" />
                      )}
                      <CardTitle className="text-lg">
                        {rec.title}
                      </CardTitle>
                    </div>
                    <Badge
                      variant={
                        rec.priority === "high"
                          ? "destructive"
                          : rec.priority === "medium"
                            ? "default"
                            : "secondary"
                      }
                    >
                      {rec.priority}
                    </Badge>
                  </div>
                  <CardDescription className="text-base">
                    {rec.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-green-600">
                        {rec.impact}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          AI Confidence:
                        </span>
                        <Progress
                          value={rec.confidence}
                          className="w-20 h-2"
                        />
                        <span className="text-sm font-medium">
                          {rec.confidence}%
                        </span>
                      </div>
                    </div>
                    <Button size="sm">Apply</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Predictions Tab */}
        <TabsContent value="predictions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Value Prediction</CardTitle>
              <CardDescription>
                AI-powered 6-month portfolio forecast
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={predictionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="actual"
                    stroke="#8884d8"
                    strokeWidth={2}
                    name="Actual Value"
                  />
                  <Line
                    type="monotone"
                    dataKey="predicted"
                    stroke="#82ca9d"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name="Predicted Value"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Allocation Optimization</CardTitle>
                <CardDescription>
                  Current vs AI-optimized allocation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={optimizationData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {optimizationData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.color}
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Expected Outcomes</CardTitle>
                <CardDescription>
                  Projected results with AI optimization
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Annual Return</span>
                  <span className="font-semibold text-green-600">
                    +2.3%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">
                    Risk Reduction
                  </span>
                  <span className="font-semibold text-blue-600">
                    -15%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Sharpe Ratio</span>
                  <span className="font-semibold text-purple-600">
                    1.34
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Max Drawdown</span>
                  <span className="font-semibold text-orange-600">
                    -8.2%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Risk Analysis Tab */}
        <TabsContent value="risk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Risk vs Allocation Analysis</CardTitle>
              <CardDescription>
                Current portfolio risk distribution
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={riskAnalysisData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar
                    dataKey="risk"
                    fill="#ef4444"
                    name="Risk Score"
                  />
                  <Bar
                    dataKey="allocation"
                    fill="#3b82f6"
                    name="Allocation %"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Market Sentiment Tab */}
        <TabsContent value="sentiment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                AI Market Sentiment Analysis
              </CardTitle>
              <CardDescription>
                Real-time sentiment scoring across sectors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {marketSentimentData.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="font-medium">
                        {item.category}
                      </div>
                      {item.change > 0 ? (
                        <TrendingUp className="h-4 w-4 text-green-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-500" />
                      )}
                      <span
                        className={`text-sm ${item.change > 0 ? "text-green-600" : "text-red-600"}`}
                      >
                        {item.change > 0 ? "+" : ""}
                        {item.change}%
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Progress
                        value={item.sentiment}
                        className="w-20 h-2"
                      />
                      <span className="font-medium w-12">
                        {item.sentiment}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}