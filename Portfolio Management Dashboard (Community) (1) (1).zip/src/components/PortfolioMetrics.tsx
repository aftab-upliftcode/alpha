import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { TrendingUp, TrendingDown, DollarSign, Percent } from "lucide-react";

const metrics = [
  {
    title: "Total Value",
    value: "$124,567.89",
    change: "+$2,345.67",
    changePercent: "+1.92%",
    isPositive: true,
    icon: DollarSign,
  },
  {
    title: "Today's Change",
    value: "+$1,234.56",
    change: "+0.99%",
    changePercent: "vs yesterday",
    isPositive: true,
    icon: TrendingUp,
  },
  {
    title: "Total Return",
    value: "+$24,567.89",
    change: "+24.56%",
    changePercent: "all time",
    isPositive: true,
    icon: Percent,
  },
  {
    title: "Cash Balance",
    value: "$8,432.10",
    change: "Available",
    changePercent: "to invest",
    isPositive: null,
    icon: DollarSign,
  },
];

export function PortfolioMetrics() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {metrics.map((metric) => (
        <Card key={metric.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
            <metric.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metric.value}</div>
            <div className="flex items-center space-x-1 text-xs">
              {metric.isPositive === true && (
                <TrendingUp className="h-3 w-3 text-green-600" />
              )}
              {metric.isPositive === false && (
                <TrendingDown className="h-3 w-3 text-red-600" />
              )}
              <span
                className={
                  metric.isPositive === true
                    ? "text-green-600"
                    : metric.isPositive === false
                    ? "text-red-600"
                    : "text-muted-foreground"
                }
              >
                {metric.change}
              </span>
              <span className="text-muted-foreground">{metric.changePercent}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}