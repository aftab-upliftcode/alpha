import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const performanceData = [
  { date: "Jan 2024", portfolio: 95000, benchmark: 96000 },
  { date: "Feb 2024", portfolio: 98000, benchmark: 98500 },
  { date: "Mar 2024", portfolio: 102000, benchmark: 101000 },
  { date: "Apr 2024", portfolio: 105000, benchmark: 103000 },
  { date: "May 2024", portfolio: 108000, benchmark: 105500 },
  { date: "Jun 2024", portfolio: 112000, benchmark: 108000 },
  { date: "Jul 2024", portfolio: 115000, benchmark: 110500 },
  { date: "Aug 2024", portfolio: 118000, benchmark: 113000 },
  { date: "Sep 2024", portfolio: 121000, benchmark: 115500 },
  { date: "Oct 2024", portfolio: 119000, benchmark: 114000 },
  { date: "Nov 2024", portfolio: 122000, benchmark: 117000 },
  { date: "Dec 2024", portfolio: 124568, benchmark: 119500 },
];

export function PerformanceChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Portfolio Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart
            data={performanceData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 12 }}
            />
            <YAxis 
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip 
              formatter={(value: number, name: string) => [
                `$${value.toLocaleString()}`, 
                name === 'portfolio' ? 'Your Portfolio' : 'S&P 500'
              ]}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="portfolio"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              name="Your Portfolio"
            />
            <Line
              type="monotone"
              dataKey="benchmark"
              stroke="hsl(var(--muted-foreground))"
              strokeWidth={2}
              strokeDasharray="5 5"
              name="S&P 500"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}