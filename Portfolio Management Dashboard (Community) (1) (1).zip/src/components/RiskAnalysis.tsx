import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  ComposedChart,
  ReferenceLine
} from "recharts";
import { 
  Target, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Shield,
  Search,
  Calendar,
  DollarSign,
  Activity,
  BarChart3,
  PieChart,
  Briefcase,
  Users,
  FileText,
  Phone,
  PlayCircle,
  Download,
  Eye,
  Star
} from "lucide-react";

// Mock stock data
const stocks = [
  { symbol: "AAPL", name: "Apple Inc.", sector: "Technology", marketCap: "3.2T" },
  { symbol: "MSFT", name: "Microsoft Corp.", sector: "Technology", marketCap: "2.8T" },
  { symbol: "GOOGL", name: "Alphabet Inc.", sector: "Technology", marketCap: "1.7T" },
  { symbol: "AMZN", name: "Amazon.com Inc.", sector: "Consumer Discretionary", marketCap: "1.5T" },
  { symbol: "TSLA", name: "Tesla Inc.", sector: "Automotive", marketCap: "800B" },
  { symbol: "JPM", name: "JPMorgan Chase & Co.", sector: "Financial Services", marketCap: "450B" },
  { symbol: "JNJ", name: "Johnson & Johnson", sector: "Healthcare", marketCap: "420B" },
  { symbol: "V", name: "Visa Inc.", sector: "Financial Services", marketCap: "520B" }
];

// Mock financial data for selected stock
const getFinancialData = (symbol: string) => ({
  fundamentals: {
    peRatio: 28.5,
    pegRatio: 1.2,
    priceToBook: 6.8,
    priceToSales: 7.2,
    enterpriseValue: "3.1T",
    evToEbitda: 22.4,
    debtToEquity: 1.73,
    currentRatio: 1.05,
    quickRatio: 0.83,
    returnOnEquity: 0.26,
    returnOnAssets: 0.22,
    grossMargin: 0.44,
    operatingMargin: 0.31,
    netMargin: 0.26,
    freeCashFlowYield: 0.03,
    dividendYield: 0.0044,
    payoutRatio: 0.15,
    betaFiveYear: 1.24,
    eps: 6.16,
    bookValuePerShare: 4.84,
    tangibleBookValue: 4.84,
    workingCapital: "15.6B"
  },
  valuation: {
    intrinsicValue: 185.50,
    targetPrice: 195.00,
    analystRating: "BUY",
    priceTarget52W: { low: 165, high: 220 },
    fairValue: 188.75,
    discountedCashFlow: 192.30,
    comparableCompanyAnalysis: 178.90,
    precedentTransactions: 201.45
  },
  riskMetrics: {
    valueAtRisk: 0.15,
    conditionalVaR: 0.22,
    sharpeRatio: 1.34,
    sortinoRatio: 1.89,
    maximumDrawdown: 0.28,
    volatility: 0.31,
    skewness: -0.15,
    kurtosis: 3.2,
    trackingError: 0.08,
    informationRatio: 0.45,
    calmarRatio: 0.89,
    omegaRatio: 1.23
  }
});

const quarterlyResults = [
  { quarter: "Q4 2023", revenue: 119.58, eps: 2.18, ebitda: 40.3, operatingIncome: 37.0, netIncome: 33.9 },
  { quarter: "Q3 2023", revenue: 89.50, eps: 1.46, ebitda: 31.8, operatingIncome: 29.5, netIncome: 22.9 },
  { quarter: "Q2 2023", revenue: 81.80, eps: 1.26, ebitda: 29.4, operatingIncome: 27.2, netIncome: 19.9 },
  { quarter: "Q1 2023", revenue: 94.84, eps: 1.52, ebitda: 33.2, operatingIncome: 30.7, netIncome: 24.2 }
];

const conferenceCalls = [
  {
    date: "2024-01-25",
    quarter: "Q4 2023",
    type: "Earnings Call",
    duration: "60 min",
    participants: 15,
    keyTopics: ["Revenue Growth", "AI Integration", "Market Expansion", "Cost Management"],
    sentiment: "Positive",
    transcript: "Available",
    recording: "Available"
  },
  {
    date: "2023-10-26",
    quarter: "Q3 2023", 
    type: "Earnings Call",
    duration: "55 min",
    participants: 12,
    keyTopics: ["Supply Chain", "Product Innovation", "Margin Improvement"],
    sentiment: "Neutral",
    transcript: "Available",
    recording: "Available"
  },
  {
    date: "2023-07-27",
    quarter: "Q2 2023",
    type: "Earnings Call", 
    duration: "58 min",
    participants: 14,
    keyTopics: ["Services Growth", "International Markets", "R&D Investment"],
    sentiment: "Positive",
    transcript: "Available",
    recording: "Available"
  }
];

const privateMarketResearch = [
  {
    title: "Private Equity Deployment in Tech Sector",
    firm: "Alpha Capital Research",
    date: "2024-01-15",
    rating: "Overweight",
    targetPrice: 210,
    summary: "Strong fundamentals support premium valuation multiples",
    keyPoints: [
      "Expanding market share in emerging technologies",
      "Robust free cash flow generation capabilities", 
      "Conservative debt management strategy",
      "Superior ROIC vs industry peers"
    ]
  },
  {
    title: "Institutional Flow Analysis & Dark Pool Activity",
    firm: "Meridian Analytics",
    date: "2024-01-12",
    rating: "Buy",
    targetPrice: 205,
    summary: "Significant institutional accumulation detected",
    keyPoints: [
      "68% increase in institutional ownership QoQ",
      "Large block transactions in dark pools",
      "Hedge fund positioning shows net long bias",
      "Prime brokerage data indicates bullish sentiment"
    ]
  }
];

export function RiskAnalysis() {
  const [selectedStock, setSelectedStock] = useState<string>("AAPL");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredStocks = stocks.filter(stock => 
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stock.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentStockData = getFinancialData(selectedStock);
  const currentStock = stocks.find(s => s.symbol === selectedStock);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Target className="h-8 w-8 text-red-600" />
            Risk Analysis & Private Research
          </h1>
          <p className="text-muted-foreground mt-1">
            Comprehensive risk assessment and institutional-grade market research
          </p>
        </div>
        <Badge variant="secondary" className="bg-red-100 text-red-700">
          <Shield className="h-3 w-3 mr-1" />
          Confidential Research
        </Badge>
      </div>

      {/* Stock Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Security Selection
          </CardTitle>
          <CardDescription>
            Select a security for detailed risk analysis and private market research
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 items-end">
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Search Securities</label>
              <Input
                placeholder="Search by symbol or company name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="w-64">
              <label className="text-sm font-medium mb-2 block">Select Security</label>
              <Select value={selectedStock} onValueChange={setSelectedStock}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {filteredStocks.map((stock) => (
                    <SelectItem key={stock.symbol} value={stock.symbol}>
                      {stock.symbol} - {stock.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Selected Stock Overview */}
      {currentStock && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">{currentStock.symbol} - {currentStock.name}</CardTitle>
                <CardDescription className="text-base">{currentStock.sector} • Market Cap: {currentStock.marketCap}</CardDescription>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-600">$173.50</div>
                <div className="flex items-center text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  +2.45 (+1.43%)
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>
      )}

      {/* Main Analysis Tabs */}
      <Tabs defaultValue="financials" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="financials">Financial Analysis</TabsTrigger>
          <TabsTrigger value="quarterly">Quarterly Results</TabsTrigger>
          <TabsTrigger value="conference">Conference Calls</TabsTrigger>
          <TabsTrigger value="research">Private Research</TabsTrigger>
        </TabsList>

        {/* Financial Analysis Tab */}
        <TabsContent value="financials" className="space-y-6">
          {/* Key Ratios */}
          <Card>
            <CardHeader>
              <CardTitle>Fundamental Ratios & Valuation Metrics</CardTitle>
              <CardDescription>Core financial ratios and valuation analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-blue-600">Valuation Ratios</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">P/E Ratio</span>
                      <span className="font-medium">{currentStockData.fundamentals.peRatio}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">PEG Ratio</span>
                      <span className="font-medium">{currentStockData.fundamentals.pegRatio}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">P/B Ratio</span>
                      <span className="font-medium">{currentStockData.fundamentals.priceToBook}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">P/S Ratio</span>
                      <span className="font-medium">{currentStockData.fundamentals.priceToSales}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">EV/EBITDA</span>
                      <span className="font-medium">{currentStockData.fundamentals.evToEbitda}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-green-600">Profitability</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">ROE</span>
                      <span className="font-medium">{(currentStockData.fundamentals.returnOnEquity * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">ROA</span>
                      <span className="font-medium">{(currentStockData.fundamentals.returnOnAssets * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Gross Margin</span>
                      <span className="font-medium">{(currentStockData.fundamentals.grossMargin * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Operating Margin</span>
                      <span className="font-medium">{(currentStockData.fundamentals.operatingMargin * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Net Margin</span>
                      <span className="font-medium">{(currentStockData.fundamentals.netMargin * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-orange-600">Liquidity & Leverage</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Current Ratio</span>
                      <span className="font-medium">{currentStockData.fundamentals.currentRatio}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Quick Ratio</span>
                      <span className="font-medium">{currentStockData.fundamentals.quickRatio}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Debt/Equity</span>
                      <span className="font-medium">{currentStockData.fundamentals.debtToEquity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Working Capital</span>
                      <span className="font-medium">{currentStockData.fundamentals.workingCapital}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">FCF Yield</span>
                      <span className="font-medium">{(currentStockData.fundamentals.freeCashFlowYield * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-purple-600">Risk Metrics</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Beta (5Y)</span>
                      <span className="font-medium">{currentStockData.fundamentals.betaFiveYear}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Volatility</span>
                      <span className="font-medium">{(currentStockData.riskMetrics.volatility * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">VaR (95%)</span>
                      <span className="font-medium text-red-600">{(currentStockData.riskMetrics.valueAtRisk * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Sharpe Ratio</span>
                      <span className="font-medium">{currentStockData.riskMetrics.sharpeRatio}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Max Drawdown</span>
                      <span className="font-medium text-red-600">{(currentStockData.riskMetrics.maximumDrawdown * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Valuation Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Valuation Analysis</CardTitle>
                <CardDescription>Multiple valuation methodologies and price targets</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Intrinsic Value (DCF)</span>
                    <span className="font-semibold text-green-600">${currentStockData.valuation.intrinsicValue}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Comparable Company Analysis</span>
                    <span className="font-semibold">${currentStockData.valuation.comparableCompanyAnalysis}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Precedent Transactions</span>
                    <span className="font-semibold">${currentStockData.valuation.precedentTransactions}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Analyst Consensus</span>
                    <span className="font-semibold text-blue-600">${currentStockData.valuation.targetPrice}</span>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Fair Value Estimate</span>
                    <span className="text-lg font-bold text-green-600">${currentStockData.valuation.fairValue}</span>
                  </div>
                  <Badge variant="secondary" className="mt-2 bg-green-100 text-green-700">
                    {currentStockData.valuation.analystRating}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Assessment Matrix</CardTitle>
                <CardDescription>Advanced risk metrics and portfolio impact analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Value at Risk (VaR)</span>
                    <span className="font-medium text-red-600">{(currentStockData.riskMetrics.valueAtRisk * 100).toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Conditional VaR</span>
                    <span className="font-medium text-red-600">{(currentStockData.riskMetrics.conditionalVaR * 100).toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sortino Ratio</span>
                    <span className="font-medium">{currentStockData.riskMetrics.sortinoRatio}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Information Ratio</span>
                    <span className="font-medium">{currentStockData.riskMetrics.informationRatio}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Calmar Ratio</span>
                    <span className="font-medium">{currentStockData.riskMetrics.calmarRatio}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Omega Ratio</span>
                    <span className="font-medium">{currentStockData.riskMetrics.omegaRatio}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tracking Error</span>
                    <span className="font-medium">{(currentStockData.riskMetrics.trackingError * 100).toFixed(2)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Quarterly Results Tab */}
        <TabsContent value="quarterly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quarterly Financial Performance</CardTitle>
              <CardDescription>Historical quarterly results and key performance indicators</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={quarterlyResults}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="quarter" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Bar yAxisId="left" dataKey="revenue" fill="#3b82f6" name="Revenue (B)" />
                  <Line yAxisId="right" type="monotone" dataKey="eps" stroke="#ef4444" strokeWidth={3} name="EPS" />
                  <Line yAxisId="left" type="monotone" dataKey="ebitda" stroke="#10b981" strokeWidth={2} name="EBITDA (B)" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {quarterlyResults.map((quarter, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{quarter.quarter}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Revenue</span>
                    <span className="font-medium">${quarter.revenue}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">EPS</span>
                    <span className="font-medium">${quarter.eps}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">EBITDA</span>
                    <span className="font-medium">${quarter.ebitda}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Operating Income</span>
                    <span className="font-medium">${quarter.operatingIncome}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Net Income</span>
                    <span className="font-medium">${quarter.netIncome}B</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Conference Calls Tab */}
        <TabsContent value="conference" className="space-y-6">
          <div className="grid gap-4">
            {conferenceCalls.map((call, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Phone className="h-5 w-5" />
                        {call.quarter} {call.type}
                      </CardTitle>
                      <CardDescription>{call.date} • {call.duration} • {call.participants} participants</CardDescription>
                    </div>
                    <Badge variant={call.sentiment === "Positive" ? "default" : call.sentiment === "Negative" ? "destructive" : "secondary"}>
                      {call.sentiment}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Key Discussion Topics</h4>
                      <div className="flex flex-wrap gap-2">
                        {call.keyTopics.map((topic, topicIndex) => (
                          <Badge key={topicIndex} variant="outline">{topic}</Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex items-center gap-1">
                        <PlayCircle className="h-4 w-4" />
                        Listen to Recording
                      </Button>
                      <Button size="sm" variant="outline" className="flex items-center gap-1">
                        <FileText className="h-4 w-4" />
                        View Transcript
                      </Button>
                      <Button size="sm" variant="outline" className="flex items-center gap-1">
                        <Download className="h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Private Research Tab */}
        <TabsContent value="research" className="space-y-6">
          <div className="grid gap-6">
            {privateMarketResearch.map((research, index) => (
              <Card key={index} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Briefcase className="h-5 w-5" />
                        {research.title}
                      </CardTitle>
                      <CardDescription>{research.firm} • {research.date}</CardDescription>
                    </div>
                    <div className="text-right">
                      <Badge variant="default" className="mb-2">{research.rating}</Badge>
                      <div className="text-lg font-bold text-blue-600">PT: ${research.targetPrice}</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm font-medium text-muted-foreground">{research.summary}</p>
                    
                    <div>
                      <h4 className="font-medium mb-2 flex items-center gap-1">
                        <Star className="h-4 w-4" />
                        Key Investment Thesis Points
                      </h4>
                      <ul className="space-y-1">
                        {research.keyPoints.map((point, pointIndex) => (
                          <li key={pointIndex} className="text-sm flex items-start gap-2">
                            <span className="text-blue-600 font-bold">•</span>
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="flex gap-2 pt-2">
                      <Button size="sm" variant="outline" className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        View Full Report
                      </Button>
                      <Button size="sm" variant="outline" className="flex items-center gap-1">
                        <Download className="h-4 w-4" />
                        Download PDF
                      </Button>
                      <Badge variant="secondary" className="bg-red-100 text-red-700">
                        <Shield className="h-3 w-3 mr-1" />
                        Confidential
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Alternative Data Sources</CardTitle>
              <CardDescription>Non-traditional data points for enhanced investment decision making</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Satellite Data</h4>
                  <p className="text-sm text-muted-foreground">Parking lot occupancy, construction activity, agricultural yield estimates</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Social Sentiment</h4>
                  <p className="text-sm text-muted-foreground">News sentiment analysis, social media monitoring, executive communications</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Patent Filings</h4>
                  <p className="text-sm text-muted-foreground">Innovation pipeline tracking, competitive advantage analysis, R&D intensity</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}