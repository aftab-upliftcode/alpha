import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ArrowUpCircle, ArrowDownCircle } from "lucide-react";

const transactions = [
  {
    id: 1,
    type: "BUY",
    symbol: "NVDA",
    company: "NVIDIA Corporation",
    shares: 20,
    price: 875.20,
    amount: 17504.00,
    date: "2024-07-25",
    time: "09:30 AM",
  },
  {
    id: 2,
    type: "SELL",
    symbol: "TSLA",
    company: "Tesla Inc.",
    shares: 50,
    price: 245.60,
    amount: 12280.00,
    date: "2024-07-24",
    time: "02:15 PM",
  },
  {
    id: 3,
    type: "BUY",
    symbol: "AAPL",
    company: "Apple Inc.",
    shares: 75,
    price: 189.95,
    amount: 14246.25,
    date: "2024-07-23",
    time: "11:45 AM",
  },
  {
    id: 4,
    type: "DIVIDEND",
    symbol: "GOOGL",
    company: "Alphabet Inc.",
    shares: 75,
    price: 2.50,
    amount: 187.50,
    date: "2024-07-22",
    time: "12:00 PM",
  },
  {
    id: 5,
    type: "BUY",
    symbol: "AMZN",
    company: "Amazon.com Inc.",
    shares: 25,
    price: 3287.50,
    amount: 82187.50,
    date: "2024-07-21",
    time: "10:30 AM",
  },
];

export function RecentTransactions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center space-x-4 rounded-lg border p-4">
              <div className="flex-shrink-0">
                {transaction.type === "BUY" || transaction.type === "DIVIDEND" ? (
                  <ArrowDownCircle className="h-8 w-8 text-green-600" />
                ) : (
                  <ArrowUpCircle className="h-8 w-8 text-red-600" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{transaction.symbol}</p>
                    <p className="text-sm text-muted-foreground">{transaction.company}</p>
                  </div>
                  <Badge
                    variant={
                      transaction.type === "BUY" || transaction.type === "DIVIDEND"
                        ? "default"
                        : "destructive"
                    }
                  >
                    {transaction.type}
                  </Badge>
                </div>
                <div className="mt-1 flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    {transaction.type === "DIVIDEND" 
                      ? `${transaction.shares} shares @ $${transaction.price} per share`
                      : `${transaction.shares} shares @ $${transaction.price}`
                    }
                  </div>
                  <div className="text-right">
                    <p className="font-medium">
                      {transaction.type === "SELL" ? "+" : "-"}${transaction.amount.toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {transaction.date} at {transaction.time}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}