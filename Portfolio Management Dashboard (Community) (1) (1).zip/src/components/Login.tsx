import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import {
  Eye,
  EyeOff,
  TrendingUp,
  Shield,
  PieChart,
  BarChart3,
} from "lucide-react";

interface LoginProps {
  onLogin: (email: string, password: string) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Basic validation
    if (!email || !password) {
      setError("Please fill in all fields");
      setIsLoading(false);
      return;
    }

    if (!email.includes("@")) {
      setError("Please enter a valid email address");
      setIsLoading(false);
      return;
    }

    // Simulate login delay
    setTimeout(() => {
      onLogin(email, password);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Floating Shapes Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {/* Large Circle - Top Right */}
        <div
          className="floating-shape animate-float absolute rounded-full"
          style={{
            top: "10%",
            right: "5%",
            width: "300px",
            height: "300px",
            background:
              "linear-gradient(135deg, rgba(255, 107, 107, 0.08), rgba(78, 84, 200, 0.06))",
            animationDelay: "0s",
          }}
        />

        {/* Medium Triangle - Top Left */}
        <div
          className="floating-shape animate-float-reverse absolute"
          style={{
            top: "15%",
            left: "8%",
            width: "180px",
            height: "180px",
            background:
              "linear-gradient(135deg, rgba(34, 197, 94, 0.08), rgba(59, 130, 246, 0.06))",
            clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
            animationDelay: "2s",
          }}
        />

        {/* Square - Bottom Right */}
        <div
          className="floating-shape animate-float-and-rotate absolute"
          style={{
            bottom: "25%",
            right: "20%",
            width: "80px",
            height: "80px",
            background:
              "linear-gradient(135deg, rgba(251, 191, 36, 0.1), rgba(245, 101, 101, 0.08))",
            animationDelay: "4s",
          }}
        />

        {/* Hexagon - Middle Left */}
        <div
          className="floating-shape animate-float-reverse absolute"
          style={{
            top: "45%",
            left: "15%",
            width: "120px",
            height: "120px",
            background:
              "linear-gradient(135deg, rgba(236, 72, 153, 0.08), rgba(239, 68, 68, 0.06))",
            clipPath:
              "polygon(30% 0%, 70% 0%, 100% 50%, 70% 100%, 30% 100%, 0% 50%)",
            animationDelay: "6s",
          }}
        />

        {/* Diamond - Bottom Left */}
        <div
          className="floating-shape animate-float-and-spin absolute"
          style={{
            bottom: "15%",
            left: "25%",
            width: "100px",
            height: "100px",
            background:
              "linear-gradient(135deg, rgba(6, 182, 212, 0.1), rgba(20, 184, 166, 0.08))",
            animationDelay: "1s",
          }}
        />

        {/* Pentagon - Bottom Center */}
        <div
          className="floating-shape animate-float-reverse absolute"
          style={{
            bottom: "20%",
            right: "35%",
            width: "140px",
            height: "140px",
            background:
              "linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(147, 51, 234, 0.06))",
            clipPath:
              "polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)",
            animationDelay: "3s",
          }}
        />

        {/* Circle - Top Center */}
        <div
          className="floating-shape animate-float absolute rounded-full"
          style={{
            top: "30%",
            left: "45%",
            width: "60px",
            height: "60px",
            background:
              "linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(34, 197, 94, 0.1))",
            animationDuration: "10s",
            animationDelay: "5s",
          }}
        />

        {/* Small Circle - Bottom Center */}
        <div
          className="floating-shape animate-float-reverse absolute rounded-full"
          style={{
            bottom: "35%",
            left: "55%",
            width: "40px",
            height: "40px",
            background:
              "linear-gradient(135deg, rgba(139, 92, 246, 0.14), rgba(168, 85, 247, 0.12))",
            animationDuration: "8s",
            animationDelay: "7s",
          }}
        />

        {/* Oval - Top Center Left */}
        <div
          className="floating-shape animate-float-and-wiggle absolute rounded-full"
          style={{
            top: "20%",
            left: "40%",
            width: "100px",
            height: "60px",
            background:
              "linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(236, 72, 153, 0.08))",
            animationDelay: "2.5s",
          }}
        />

        {/* Star - Bottom Right Corner */}
        <div
          className="floating-shape animate-float-and-rotate absolute"
          style={{
            bottom: "10%",
            right: "8%",
            width: "90px",
            height: "90px",
            background:
              "linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(251, 191, 36, 0.08))",
            clipPath:
              "polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)",
            animationDuration: "15s",
            animationDelay: "4.5s",
          }}
        />

        {/* Small Accent Dots */}
        <div
          className="floating-shape animate-float absolute rounded-full"
          style={{
            top: "40%",
            right: "12%",
            width: "25px",
            height: "25px",
            background:
              "linear-gradient(135deg, rgba(59, 130, 246, 0.16), rgba(99, 102, 241, 0.14))",
            animationDuration: "6s",
            animationDelay: "1.5s",
          }}
        />

        <div
          className="floating-shape animate-float-and-rotate absolute"
          style={{
            bottom: "45%",
            left: "12%",
            width: "30px",
            height: "30px",
            background:
              "linear-gradient(135deg, rgba(34, 197, 94, 0.14), rgba(16, 185, 129, 0.12))",
            animationDuration: "18s",
            animationDirection: "reverse",
            animationDelay: "3.5s",
          }}
        />

        {/* Additional Medium Shapes for More Visual Interest */}
        <div
          className="floating-shape animate-float absolute rounded-full"
          style={{
            top: "60%",
            right: "25%",
            width: "70px",
            height: "70px",
            background:
              "linear-gradient(135deg, rgba(168, 85, 247, 0.08), rgba(147, 51, 234, 0.06))",
            animationDuration: "17s",
            animationDelay: "8s",
          }}
        />

        <div
          className="floating-shape animate-float-and-rotate absolute"
          style={{
            top: "70%",
            left: "35%",
            width: "50px",
            height: "50px",
            background:
              "linear-gradient(135deg, rgba(20, 184, 166, 0.1), rgba(6, 182, 212, 0.08))",
            animationDuration: "22s",
            animationDirection: "reverse",
            animationDelay: "6.5s",
          }}
        />
      </div>

      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding and features */}
        <div className="hidden lg:flex flex-col justify-center space-y-8 px-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground">
                  Alpha.ai
                </h1>
                <p className="text-muted-foreground">
                  AI-Powered Family Office Investment Management
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-chart-1/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <BarChart3 className="w-5 h-5 text-chart-1" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">
                  Advanced Analytics
                </h3>
                <p className="text-muted-foreground text-sm">
                  Institutional-grade financial data with
                  detailed insights.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-chart-2/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <PieChart className="w-5 h-5 text-chart-2" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">
                  Portfolio-Management
                </h3>
                <p className="text-muted-foreground text-sm">
                  Multi-assest Portfolio Tracker
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-chart-2/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Shield className="w-5 h-5 text-chart-4" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">
                  Secure & Reliable
                </h3>
                <p className="text-muted-foreground text-sm">
                  Bank-level security with encrypted data
                  transmission and role based authentication
                  protocols.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-chart-3/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-5 h-5 text-chart-3" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">
                  Smart Insights
                </h3>
                <p className="text-muted-foreground text-sm">
                  AI-powered recommendations and market analysis
                  to optimize your investment strategy.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login form */}
        <div className="flex justify-center">
          <Card className="w-full max-w-md">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl text-center">
                Welcome back
              </CardTitle>
              <CardDescription className="text-center">
                Sign in to your Alpha.ai account to access your
                dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form
                onSubmit={handleSubmit}
                className="space-y-4"
              >
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoading}
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) =>
                        setPassword(e.target.value)
                      }
                      disabled={isLoading}
                      className="h-11 pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() =>
                        setShowPassword(!showPassword)
                      }
                      disabled={isLoading}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="remember"
                      className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2"
                    />
                    <Label
                      htmlFor="remember"
                      className="text-sm text-muted-foreground"
                    >
                      Remember me
                    </Label>
                  </div>
                  <Button
                    variant="link"
                    className="px-0 text-sm"
                  >
                    Forgot password?
                  </Button>
                </div>

                <Button
                  type="submit"
                  className="w-full h-11"
                  disabled={isLoading}
                >
                  {isLoading ? "Signing in..." : "Sign in"}
                </Button>

                <div className="text-center text-sm text-muted-foreground">
                  Don't have an account?{" "}
                  <Button
                    variant="link"
                    className="px-0 text-sm"
                  >
                    Contact your administrator
                  </Button>
                </div>
              </form>

              {/* Demo credentials */}
              <div className="mt-6 p-4 bg-muted/30 rounded-lg border border-dashed border-border">
                <p className="text-sm font-medium text-foreground mb-2">
                  Demo Credentials:
                </p>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>
                    <strong>Email:</strong> demo@alpha.ai
                  </p>
                  <p>
                    <strong>Password:</strong> demo123
                  </p>
                  <p className="text-xs mt-2 italic">
                    Use any email/password combination to access
                    the demo
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}