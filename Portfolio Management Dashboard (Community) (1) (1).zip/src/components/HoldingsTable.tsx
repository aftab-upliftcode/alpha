import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, TrendingDown } from "lucide-react";

const holdings = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    shares: 150,
    avgCost: 145.30,
    currentPrice: 189.95,
    marketValue: 28492.50,
    unrealizedGain: 6697.50,
    unrealizedGainPercent: 30.77,
    sector: "Technology",
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    shares: 75,
    avgCost: 2234.50,
    currentPrice: 2789.30,
    marketValue: 209197.50,
    unrealizedGain: 41610.00,
    unrealizedGainPercent: 24.84,
    sector: "Technology",
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    shares: 100,
    avgCost: 245.60,
    currentPrice: 201.20,
    marketValue: 20120.00,
    unrealizedGain: -4440.00,
    unrealizedGainPercent: -18.07,
    sector: "Automotive",
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    shares: 50,
    avgCost: 3100.00,
    currentPrice: 3287.50,
    marketValue: 164375.00,
    unrealizedGain: 9375.00,
    unrealizedGainPercent: 6.05,
    sector: "E-commerce",
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corporation",
    shares: 80,
    avgCost: 420.75,
    currentPrice: 875.20,
    marketValue: 70016.00,
    unrealizedGain: 36356.00,
    unrealizedGainPercent: 108.03,
    sector: "Technology",
  },
];

const getSectorColor = (sector: string) => {
  const colors: { [key: string]: string } = {
    Technology: "bg-blue-100 text-blue-800",
    Automotive: "bg-green-100 text-green-800",
    "E-commerce": "bg-purple-100 text-purple-800",
  };
  return colors[sector] || "bg-gray-100 text-gray-800";
};

export function HoldingsTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Current Holdings</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Symbol</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Sector</TableHead>
              <TableHead className="text-right">Shares</TableHead>
              <TableHead className="text-right">Avg Cost</TableHead>
              <TableHead className="text-right">Current Price</TableHead>
              <TableHead className="text-right">Market Value</TableHead>
              <TableHead className="text-right">Unrealized P&L</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {holdings.map((holding) => (
              <TableRow key={holding.symbol}>
                <TableCell className="font-medium">{holding.symbol}</TableCell>
                <TableCell>{holding.name}</TableCell>
                <TableCell>
                  <Badge variant="secondary" className={getSectorColor(holding.sector)}>
                    {holding.sector}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">{holding.shares}</TableCell>
                <TableCell className="text-right">${holding.avgCost.toFixed(2)}</TableCell>
                <TableCell className="text-right">${holding.currentPrice.toFixed(2)}</TableCell>
                <TableCell className="text-right">${holding.marketValue.toLocaleString()}</TableCell>
                <TableCell className="text-right">
                  <div className={`flex items-center justify-end space-x-1 ${
                    holding.unrealizedGain >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {holding.unrealizedGain >= 0 ? (
                      <TrendingUp className="h-3 w-3" />
                    ) : (
                      <TrendingDown className="h-3 w-3" />
                    )}
                    <div className="text-right">
                      <div>${Math.abs(holding.unrealizedGain).toLocaleString()}</div>
                      <div className="text-xs">({holding.unrealizedGainPercent.toFixed(2)}%)</div>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}