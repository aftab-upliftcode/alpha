import { useState } from "react";
import {
  SidebarProvider,
  SidebarTrigger,
} from "./components/ui/sidebar";
import { TopNavigation } from "./components/TopNavigation";
import { PortfolioSidebar } from "./components/PortfolioSidebar";
import { PortfolioMetrics } from "./components/PortfolioMetrics";
import { HoldingsTable } from "./components/HoldingsTable";
import { PerformanceChart } from "./components/PerformanceChart";
import { AssetAllocation } from "./components/AssetAllocation";
import { RecentTransactions } from "./components/RecentTransactions";
import { Watchlist } from "./components/Watchlist";
import { AIInsights } from "./components/AIInsights";
import { Holdings } from "./components/Holdings";
import { RiskAnalysis } from "./components/RiskAnalysis";
import { Login } from "./components/Login";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "./components/ui/breadcrumb";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<{
    email: string;
    name: string;
  } | null>(null);
  const [currentPage, setCurrentPage] = useState("Dashboard");

  const handleLogin = (email: string, password: string) => {
    // Mock authentication - in a real app, this would validate against a backend
    const mockUser = {
      email: email,
      name:
        email === "demo@alpha.ai"
          ? "Demo User"
          : email.split("@")[0],
    };

    setCurrentUser(mockUser);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
  };

  const renderPageContent = () => {
    switch (currentPage) {
      case "AI insight":
        return <AIInsights />;
      case "Holdings":
        return <Holdings />;
      case "Risk Analysis":
        return <RiskAnalysis />;
      case "Dashboard":
      default:
        return (
          <div className="space-y-6">
            {/* Key Metrics */}
            <div>
              <h2 className="text-xl font-semibold mb-4 text-foreground">
                Performance Overview
              </h2>
              <PortfolioMetrics />
            </div>

            {/* Charts Row */}
            <div>
              <h2 className="text-xl font-semibold mb-4 text-foreground">
                Analytics
              </h2>
              <div className="grid gap-6 lg:grid-cols-2">
                <PerformanceChart />
                <AssetAllocation />
              </div>
            </div>

            {/* Holdings Table */}
            <div>
              <h2 className="text-xl font-semibold mb-4 text-foreground">
                Current Holdings
              </h2>
              <HoldingsTable />
            </div>

            {/* Recent Activity Row */}
            <div>
              <h2 className="text-xl font-semibold mb-4 text-foreground">
                Recent Activity
              </h2>
              <div className="grid gap-6 lg:grid-cols-2">
                <RecentTransactions />
                <Watchlist />
              </div>
            </div>
          </div>
        );
    }
  };

  const getPageTitle = () => {
    switch (currentPage) {
      case "AI insight":
        return "AI Insights";
      case "Holdings":
        return "Holdings";
      case "Risk Analysis":
        return "Risk Analysis";
      case "Dashboard":
      default:
        return "Portfolio Dashboard";
    }
  };

  const getPageDescription = () => {
    switch (currentPage) {
      case "AI insight":
        return "AI-powered portfolio analysis and recommendations.";
      case "Holdings":
        return "Detailed view of your current portfolio holdings and positions.";
      case "Risk Analysis":
        return "Comprehensive risk assessment and institutional-grade market research.";
      case "Dashboard":
      default:
        return "Welcome back! Here's your portfolio overview for today.";
    }
  };

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }
  return (
    <SidebarProvider>
      <div className="flex h-screen w-full bg-background">
        <PortfolioSidebar
          currentPage={currentPage}
          onPageChange={setCurrentPage}
        />
        <div className="flex-1 flex flex-col overflow-hidden">
          <TopNavigation
            currentUser={currentUser}
            onLogout={handleLogout}
          />
          <main className="flex-1 overflow-auto">
            <div className="p-6">
              {/* Breadcrumb and Header */}
              <div className="mb-6">
                <Breadcrumb className="mb-4">
                  <BreadcrumbList>
                    <BreadcrumbItem>
                      <BreadcrumbLink href="/">
                        Home
                      </BreadcrumbLink>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator />
                    <BreadcrumbItem>
                      <BreadcrumbPage>
                        {getPageTitle()}
                      </BreadcrumbPage>
                    </BreadcrumbItem>
                  </BreadcrumbList>
                </Breadcrumb>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <SidebarTrigger className="lg:hidden" />
                    <div>
                      <h1 className="text-3xl font-bold text-foreground">
                        {getPageTitle()}
                      </h1>
                      <p className="text-muted-foreground mt-1">
                        {getPageDescription()}
                      </p>
                    </div>
                  </div>
                  <div className="hidden md:block text-right">
                    <p className="text-sm text-muted-foreground">
                      Last updated
                    </p>
                    <p className="text-sm font-medium">
                      2 minutes ago
                    </p>
                  </div>
                </div>
              </div>

              {renderPageContent()}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}